const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'

        // Permission Verification -- This will only run if a user has a certain permission
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    

        let user = message.mentions.users.first() || message.author; 
        let locked =  message.guild.roles.find("name", "🔒 | Locked");
        if(!locked) return message.channel.send("Please create this locked role ``🔒 | Locked`` and put it lower than bots role.");
        const embed = new Discord.RichEmbed()
        
        .setAuthor("🔒Locked User Info")
        .setColor("#9B5986")
        .addField("Locked member count:",  message.guild.members.filter(m => m.roles.exists('name', '🔒 | Locked')).size)
        .addField('Locked tag:', locked)
        message.channel.send(embed)
}

    exports.config = {
    name: 'locked.info'
    }