const Discord = require("discord.js"); 

module.exports.run = async (bot, message, args) => {

  if(!message.member.hasPermission("MANAGE_ROLES" || "ADMINISTRATOR"))  return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
  if (!args[0]) return message.channel.send('**Proper Usage:** -removerole @usernametag Roles Name');
  let rMember = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
  if(!rMember) return message.reply("Please mention a real user.");
  let role = args.join(" ").slice(22);
  if(!role) return message.reply("Please specify a role!");
  let gRole = message.guild.roles.find(`name`, role);
  if(!gRole) return message.reply("Couldn't find that role.");

  if(!rMember.roles.has(gRole.id)) return message.reply("They don't have that role.");
  await(rMember.removeRole(gRole.id));

  try{
    await rMember.send(`You've been removed from: ${gRole.name}`)
  }catch(e){
    message.channel.send(`User <@${rMember.id}>, they have been removed from ${gRole.name}. We tried to DM them, but their DMs are locked.`)
  }
}

exports.config = {
    name: 'removerole'
    }