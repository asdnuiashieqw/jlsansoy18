const Discord = require("discord.js");
const fs = require("fs");
const ms = require("ms");
let warns = JSON.parse(fs.readFileSync("./warnings.json", "utf8"));

module.exports.run = async (bot, message, args) => {

    let user = message.mentions.users.first() || message.author; 

  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.");
  let wUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0])
  if(!wUser) return message.reply(`Please specify how many warnings you would like to remove.`);
  let warnlevel = warns[wUser.id].warns;

  let Amount = args[1]

  let current = warns[user.id].warns
  if(Amount > current) return message.channel.send(`They do no have ${Amount} warnings they only have ${current}`)
  let warningsclear = Number(current) - Number(Amount);
  warns[user.id].warns = warningsclear;
  fs.writeFile("./warnings.json", JSON.stringify(warns), (err) => {
    if (err) console.log(err)
});

  message.reply(`You have removed ${Amount} warnings from <@${wUser.id}>.`);

}

exports.config = {
    name: "warnings.clear"
}