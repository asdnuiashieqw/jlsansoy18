const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    if (!message.member.hasPermission('KICK_MEMBERS')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    
    if (!args[0]) return message.channel.send('**Proper Usage:** -kick @usernametag <Reason>\nExample: -kick @David_#2469 Just a warning for you!');
  
    let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!user) return message.reply("Please enter users tag.");
    if(user.id === bot.user.id) return message.reply("I cannot allow you to kick me!");
    if(user.id === message.author.id) return message.reply("I cannot allow self harm here!");
    let reason = args.join(" ").slice(22);
    if(!reason) return message.channel.send("Please specify a reason.");
    if(user.hasPermission("MANAGE_MESSAGES")) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You cannot kick a staff member!');

    let kickchannel = message.guild.channels.find(`name`, "mod-logs");
    if(!kickchannel) return message.reply("Couldn't find channel #mod-logs, please create it.");
  
    let kickEmbed = new Discord.RichEmbed()
    .setAuthor(`Kicked | ${user.user.tag}`, "https://i.imgur.com/Isr80NO.png")
    .setColor("#36393f")
    .setThumbnail(user.user.displayAvatarURL)
    .addField("Kicked User", `<@${user.id}>`, true)
    .addField("Kicked In", message.channel, true)
    .addField("Reason", reason)
    .setTimestamp()
    .setFooter(`Kicked By: ${message.author.username}`);
  
    kickchannel.send(kickEmbed);
  
    let send = new Discord.RichEmbed()
          .setDescription(`<:guardian:473905518411382805> ${user.user} You have been kicked in **${message.guild.name}**`)
          .setThumbnail(message.guild.iconURL)
          .addField("Kicked In", message.channel, true)
          .addField("Reason", reason)
          .setTimestamp()
          .setFooter(`Banned By: ${message.author.username}`);
  
          try{
            await user.send(send)
			message.guild.member(user).kick(reason);
            message.channel.send(`<:CentralHQ_Approved:466940628656455682> User has been kicked!`);
          }catch(e){
			message.guild.member(user).kick(reason);
            message.channel.send(`<:CentralHQ_Approved:466940628656455682> User has been kicked! But we weren't able to DM them.`).then(msg => msg.delete(5000));
          }
        }
  
  exports.config = {
    name: 'kick'
    }