const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

  if (!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    
  if (!args[0]) return message.channel.send('**Proper Usage:** -ban @usernametag <Reason>\nExample: -ban @David_#2469 BYE!.');

    let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!user) return message.reply("Please enter users tag.");
    if(user.id === bot.user.id) return message.reply("I cannot allow you to ban me!");
    if(user.id === message.author.id) return message.reply("I cannot allow self harm here!");
    let reason = args.join(" ").slice(22);
    if(!reason) return message.channel.send("Please specify a reason.");
    if(user.hasPermission("MANAGE_MESSAGES")) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You cannot ban a staff member!');

  let banchannel = message.guild.channels.find(`name`, "mod-logs");
  if(!banchannel) return message.reply("Couldn't find channel #mod-logs, please create it.");

  let banEmbed = new Discord.RichEmbed()
  .setAuthor(`Banned | ${user.user.tag}`, "https://i.imgur.com/Isr80NO.png")
  .setColor("#36393f")
  .setThumbnail(user.user.displayAvatarURL)
  .addField("Banned User", `<@${user.id}>`, true)
  .addField("Banned In", message.channel, true)
  .addField("Reason", reason)
  .setTimestamp()
  .setFooter(`Banned By: ${message.author.username}`);

  banchannel.send(banEmbed);

  let send = new Discord.RichEmbed()
        .setDescription(`<:guardian:473905518411382805> ${user.user} You have been banned in **${message.guild.name}**`)
        .setThumbnail(message.guild.iconURL)
        .addField("Banned In", message.channel, true)
        .addField("Duration", "For Ever", true)
        .addField("Reason", reason)
        .setTimestamp()
        .setFooter(`Banned By: ${message.author.username}`);

        try{
          await user.send(send)
		    message.guild.member(user).ban(reason);
            message.channel.send(`<:CentralHQ_Approved:466940628656455682> User has been banned!`);
        }catch(e){
	      message.guild.member(user).ban(reason);
          message.channel.send(`<:CentralHQ_Approved:466940628656455682> User has been banned! But we weren't able to DM them.`).then(msg => msg.delete(5000));
        }
      }

exports.config = {
  name: 'ban'
  }