const Discord = require('discord.js')
const moment = require('moment');
exports.run = (bot,message,args) => {
    let prefix = '-'

    if(message.mentions.users.first()) {

        const user = message.mentions.users.first();
        if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.");
        const amount = !!parseInt(message.content.split(' ')[1]) ? parseInt(message.content.split(' ')[1]) : parseInt(message.content.split(' ')[2])
        if (!amount) return message.channel.send(`Please specify how many messages you\'d like to remove posted by ${user.tag}.`)
        if (!amount && !user) return message.channel.send('Specify a user and amount, or just an amount, of messages to delete or purge!')
        message.channel.fetchMessages({
                limit: amount
            , })
            .then((messages) => {
                if (user) {
                    const filterBy = user ? user.id : client.user.id;
                    messages = messages.filter(m => m.author.id === filterBy)
                        .array()
                        .slice(0, amount);
                }
                message.channel.bulkDelete(messages)
                    .catch(error => console.log(error.stack));
                    message.channel.send(`:white_check_mark: Successfully cleared ${args[1]} messages by __${user.tag}__.`).then(msg => msg.delete(5000));
            });

    const clearedmessages1 = message.guild.channels.find("name", "mod-logs");
    if(!clearedmessages1) return message.reply("Couldn't find channel #mod-logs, please create it.");

    const embed = new Discord.RichEmbed()
        .setTitle('Cleared Messages')
        .setAuthor(user.tag, message.author.displayAvatarURL)
        .setDescription(`User has removed ${args[1]} messages by __${user.tag}__ in ${message.channel} channel.`)
        .setColor("#777777")
        .setFooter(`Cleared `)
        .setTimestamp()

        clearedmessages1.send(embed);

    } else {
    if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.");
    if(!args[0]) return message.channel.send("Please specify how many messages you\'d like to remove.");
    message.delete();
    message.channel.bulkDelete(args[0]).then(() => {
        message.channel.send(`:white_check_mark: Successfully cleared ${args[0]} messages.`).then(msg => msg.delete(5000));


    let user = message.mentions.users.first() || message.author;

    const clearedmessages = message.guild.channels.find("name", "mod-logs");
    if(!clearedmessages) return message.reply("Couldn't find channel #mod-logs, please create it.");

    const embed = new Discord.RichEmbed()
        .setTitle('Cleared Messages')
        .setAuthor(user.tag, message.author.displayAvatarURL)
        .setDescription(`User has removed ${args[0]} messages in ${message.channel} channel.`)
        .setColor("#777777")
        .setFooter(`Cleared `)
        .setTimestamp()

        clearedmessages.send(embed);
    });
}}
    exports.config = {
    name: 'clear'
    }