const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

  //!addrole @andrew Dog Person
  if(!message.member.hasPermission("MANAGE_ROLES" || "ADMINISTRATOR"))  return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
  if (!args[0]) return message.channel.send('**Proper Usage:** -addrole @usernametag Roles Name');
  let rMember = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
  if(!rMember) return message.reply("Please mention a real user.");
  let role = args.join(" ").slice(22);
  if(!role) return message.reply("Please specify a role!");
  let gRole = message.guild.roles.find(`name`, role);
  if(!gRole) return message.reply("Couldn't find that role.");

  if(rMember.roles.has(gRole.id)) return message.reply("They already have that role.");
  await(rMember.addRole(gRole.id));

  try{
    await rMember.send(`Congrats, you have been given the role ${gRole.name}`)
  }catch(e){
    message.channel.send(`Congrats to <@${rMember.id}>, they have been given the role ${gRole.name}. We tried to DM them, but their DMs are locked.`)
  }
}

exports.config = {
    name: 'addrole'
    }