const Discord = require("discord.js");
const ms = require("ms");

module.exports.run = async (bot, message, args) => {

  //!tempmute @user 1s/m/h/d

  if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    
  if (!args[0]) return message.channel.send('**Proper Usage:** -mute @usernametag <time/blank> <Reason>\nExample: -mute @David_#2469 1h Because so.\nExample: -mute @David_2469 Get Muted For ever!');

  let mutetime = args[2];

  let arg = args.slice(0).join(" ");

  if(!isNaN(arg)){
    let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    let muterole = message.guild.roles.find(`name`, "🛇 | Muted");
    if(!muterole) return message.channel.send("Please create this mute role ``🛇 | Muted`` and put it lower than bots role.");
    let reason = args.join(" ").slice(22);
  if(!reason) return message.channel.send("Please specify a reason.");

    await(user.addRole(muterole.id));
  message.channel.send(`<@${user.id}> has been muted for ever`);

  let mutechannel = message.guild.channels.find(`name`, "mod-logs");
  if(!mutechannel) return message.reply("Couldn't find channel #mod-logs, please create it.");

  let muteEmbed = new Discord.RichEmbed()
  .setAuthor(`Muted | ${user.user.tag}`, "https://i.imgur.com/Isr80NO.png")
  .setColor("#36393f")
  .setThumbnail(user.user.displayAvatarURL)
  .addField("Muted User", `<@${user.id}>`, true)
  .addField("Muted In", message.channel, true)
  .addField("Reason", reason)
  .setTimestamp()
  .setFooter(`Muted By: ${message.author.username}`);

  mutechannel.send(muteEmbed);

  let send = new Discord.RichEmbed()
        .setDescription(`<:guardian:473905518411382805> ${user.user} You have been muted in **${message.guild.name}**`)
        .setThumbnail(message.guild.iconURL)
        .addField("Muted In", message.channel, true)
        .addField("Duration", "For Ever", true)
        .addField("Reason", reason)
        .setTimestamp()
        .setFooter(`Muted By: ${message.author.username}`);

        user.send(send)

  } else{
  let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
  let tomute = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
  if(!tomute) return message.channel.send("Couldn't find user.");
  let muterole = message.guild.roles.find(`name`, "🛇 | Muted");
  if(!muterole) return message.channel.send("Please create this mute role ``🛇 | Muted`` and put it lower than bots role.");

  let mutetime = args[1];
  if(!mutetime) return message.channel.send("You didn't specify a time!");

  let reason = args.join(" ").slice(22);
  if(!reason) return message.channel.send("Please specify a reason.");

  await(tomute.addRole(muterole.id));
  message.channel.send(`<@${tomute.id}> has been muted for ${ms(ms(mutetime))}`);

  setTimeout(function(){
    tomute.removeRole(muterole.id);
    message.channel.send(`<@${tomute.id}> has been unmuted!`);
  }, ms(mutetime));

  let mutechannel = message.guild.channels.find(`name`, "mod-logs");
  if(!mutechannel) return message.reply("Couldn't find channel #mod-logs, please create it.");

  let muteEmbed1 = new Discord.RichEmbed()
  .setAuthor(`Muted | ${user.user.tag}`, "https://i.imgur.com/Isr80NO.png")
  .setColor("#36393f")
  .setThumbnail(user.user.displayAvatarURL)
  .addField("Muted User", `<@${user.id}>`, true)
  .addField("Muted In", message.channel, true)
  .addField("Reason", reason, true)
  .addField("Muted For", mutetime, true)
  .setTimestamp()
  .setFooter(`Muted By: ${message.author.username}`);

  mutechannel.send(muteEmbed1);

  let send1 = new Discord.RichEmbed()
        .setDescription(`<:guardian:473905518411382805> ${user.user} You have been muted in **${message.guild.name}**`)
        .setThumbnail(message.guild.iconURL)
        .addField("Muted In", message.channel, true)
        .addField("Duration", mutetime, true)
        .addField("Reason", reason)
        .setTimestamp()
        .setFooter(`Muted By: ${message.author.username}`);

        user.send(send1)

  }
//end of module
}

exports.config = {
  name: 'mute'
  }