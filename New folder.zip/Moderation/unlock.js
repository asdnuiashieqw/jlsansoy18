const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'

        // Permission Verification -- This will only run if a user has a certain permission
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.'); 
        
        // First, we want to check if the user had input
        if (!args[0]) return message.channel.send('**Proper Usage:** -unlock @usernametag');

        let user = message.mentions.users.first() || message.author;
        const embed = new Discord.RichEmbed()
        
        .setAuthor("User Has Been Unlocked")
        .setThumbnail(user.avatarURL)
        .setColor("#9B5986")
        .addField("Full Username", user.tag)
        .addField("ID", user.id)
        .setFooter(`Unlocked By: ${message.author.username}`)
        
        let role = message.guild.roles.find("name", "⦾ | Staff");

        // Let's pretend you mentioned the user you want to add a role to (!addrole @user Role Name):
        let member = message.mentions.members.first();
        let locked =  message.guild.roles.find("name", "🔒 | Locked"); // To get the ID of the role
        if (!message.guild.members.get(member.id).roles.has(locked.id))return message.channel.send('This user is not locked!') // Checking if the user has the role with the ID of the locked role's id

        // Remove the role!
     
        member.removeRole(message.guild.roles.find("name", "🔒 | Locked"))

        const lockChannel = message.guild.channels.find("name", "locked");
        lockChannel.send(embed);

        console.log(user.tag, "ID", user.id, "Has Been Unlocked")
    
        let embed2 = new Discord.RichEmbed()
        .setDescription(":white_check_mark: User has been unlocked!")

        message.channel.send(embed2)
        }
    exports.config = {
    name: 'unlock'
    }