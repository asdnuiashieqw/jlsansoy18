const Discord = require('discord.js')
const ms = require('ms');

    let prefix = '-'

    exports.run = (client, message, args, tools) => {
        if (!message.member.hasPermission('MANAGE_CHANNELS')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.')
            .then(msg => msg.delete({
                timeout: 10000
            }));
        if (!client.lockit) client.lockit = [];
        let time = args.join(' ');
        let validUnlocks = ['release', 'unlock'];
        if (!time) return message.channel.send('You must set a duration for the lockdown in either hour(s), minute(s) or second(s)');
    
        if (validUnlocks.includes(time)) {
            message.channel.overwritePermissions(message.guild.id, {
                    SEND_MESSAGES: null
                })
                .then(() => {
                    message.channel.send('<:CentralHQ_Approved:466940628656455682> Lockdown has been removed.');
                    clearTimeout(client.lockit[message.channel.id]);
                    delete client.lockit[message.channel.id];
                })
                .catch(error => {
                    console.log(error);
                });
        } else {
            message.channel.overwritePermissions(message.guild.id, {
                    SEND_MESSAGES: false
                })
                .then(() => {
                    message.channel.send(`<:CentralHQ_Approved:466940628656455682> Channel has been locked for: ${ms(ms(time), { long:true })}`)
                        .then(() => {
    
                            client.lockit[message.channel.id] = setTimeout(() => {
                                message.channel.overwritePermissions(message.guild.id, {
                                        SEND_MESSAGES: null
                                    })
                                    .then(message.channel.send('<:CentralHQ_Approved:466940628656455682> Lockdown has been removed.'))
                                    .catch(console.error);
                                delete client.lockit[message.channel.id];
                            }, ms(time));
                        })
                        .catch(error => {
                            console.log(error);
                        });
                });
        }
    }
exports.config = {
    name: 'lockdown'
    }