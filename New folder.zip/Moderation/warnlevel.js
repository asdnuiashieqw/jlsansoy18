const Discord = require("discord.js");
const fs = require("fs");
const ms = require("ms");
let warns = JSON.parse(fs.readFileSync("./warnings.json", "utf8"));

module.exports.run = async (bot, message, args) => {

  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.");
  if (!args[0]) return message.channel.send('**Proper Usage:** -warnlevel @usernametag');
  let wUser = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0])
  if(!wUser) return message.reply(`It seems that ${wUser} hasn\'t been warned before thus they don't have any warning levels.`);
  let warnlevel = warns[wUser.id].warns;
  if (warnlevel === 0) return message.reply(`It seems that ${wUser} hasn\'t been warned before thus they don't have any warning levels.`);
  message.reply(`<@${wUser.id}> has ${warns[wUser.id].warns} warnings.`);

}

exports.config = {
    name: "warnlevel"
}