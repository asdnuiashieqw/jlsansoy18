const Discord = require("discord.js");
const request = require("request");
const fs = require('fs');
const moment = require('moment');

const bot = new Discord.Client()
bot.commands = new Discord.Collection()

fs.readdir("./Commands/", (err, files) => {

    if(err) console.log(err);

    console.log('----Starting to load files in Commands folder----')
    
    let jsfile = files.filter(f => f.split(".").pop() === "js")
    if(jsfile.length <= 0) {
      console.log("Couldn't find commands in Commands folder.");
      return;
    }
    
    jsfile.forEach((f, i) => {
      let props = require(`./Commands/${f}`)
      console.log(`${f} loaded`)
      bot.commands.set(props.config.name, props) // Adding the command to the commands collection so it can be called later on
    })
});

fs.readdir("./Moderation/", (err, files) => {

    if(err) console.log(err);

    console.log('----Starting to load files in Moderation folder----')
    
    let jsfile = files.filter(f => f.split(".").pop() === "js")
    if(jsfile.length <= 0) {
      console.log("Couldn't find commands in Moderation folder.");
      return;
    }
    
    jsfile.forEach((f, i) => {
      let props = require(`./Moderation/${f}`)
      console.log(`${f} loaded`)
      bot.commands.set(props.config.name, props) // Adding the command to the commands collection so it can be called later on
    })
});

fs.readdir("./AutoModeration/", (err, files) => {

    if(err) console.log(err);

    console.log('----Starting to load files in AutoModeration folder----')
    
    let jsfile = files.filter(f => f.split(".").pop() === "js")
    if(jsfile.length <= 0) {
      console.log("Couldn't find functions in AutoModeration folder.");
      return;
    }
    
    jsfile.forEach((f, i) => {
      let props = require(`./AutoModeration/${f}`)
      console.log(`${f} loaded`)
      bot.on(props.on, props.code); // Adding the command to the commands collection so it can be called later on
    })
});

fs.readdir("./StaffHelp/", (err, files) => {

    if(err) console.log(err);

    console.log('----Starting to load files in StaffHelp folder----')
    
    let jsfile = files.filter(f => f.split(".").pop() === "js")
    if(jsfile.length <= 0) {
      console.log("Couldn't find commands in StaffHelp folder.");
      return;
    }
    
    jsfile.forEach((f, i) => {
      let props = require(`./StaffHelp/${f}`)
      console.log(`${f} loaded`)
      bot.commands.set(props.config.name, props) // Adding the command to the commands collection so it can be called later on
    })
});

bot.on("ready", () => {
    
    let statuses = ['-invest <amount>'];

    setInterval(function() {
        let status = statuses[Math.floor(Math.random()*statuses.length)];
        bot.user.setPresence({ game: { name: status }, status: 'online' });
    }, 10000)

    console.log("Robux Reward")
    console.log(`${bot.user.username} is online on ${bot.guilds.size} servers!`);

});
//Bot Online

const version = ("Robux Claim");
const colour = ("#0047ff");

const prefix = "-"
const token = "Njk1MjM2NDI3MDgzOTM5OTEw.Xowe4g.a27dkwAaYOSWik_XUwT924a_t38"

bot.on("message", message => {
    if(message.author.bot) return;
    if(message.channel.type === "dm") return;
    if(message.content.indexOf(prefix) !== 0) return;
  
    let messageArray = message.content.split(" ");
    let cmd = messageArray[0];
    let args = messageArray.slice(1);
    let command = messageArray[0].slice(prefix.length) 
    let file = bot.commands.get(command)

    if(!file) return;
    file.run(bot,message,args) // Change to file so that it calls the exports.run in the command file

});

// Initialize the invite cache
const invites = {};

// A pretty useful method to create a delay without blocking the whole script.
const wait = require('util').promisify(setTimeout);

bot.on('ready', () => {
  // "ready" isn't really ready. We need to wait a spell.
  wait(1000);

  // Load all invites for all guilds and save them to the cache.
  bot.guilds.forEach(g => {
    g.fetchInvites().then(guildInvites => {
      invites[g.id] = guildInvites;
    });
  });
});

bot.on('guildMemberAdd' , member => {

      // To compare, we need to load the current invite list.
    member.guild.fetchInvites().then(guildInvites => {
    // This is the *existing* invites for the guild.
    const ei = invites[member.guild.id];
    // Look through the invites, find the one for which the uses went up.
    const invite = guildInvites.find(i => ei.get(i.code).uses < i.uses);
    // This is just to simplify the message being sent below (inviter doesn't have a tag property)
    const inviter = bot.users.get(invite.inviter.id);

    var role = member.guild.roles.find("name", "| Member")
    if (!role) return;
    member.addRole (role);

    const channel = member.guild.channels.find('name', 'welcome');
    if (!channel) return;

    const user = member.user;
    var joinedAt = moment().diff(moment(user.createdAt), 'days')
    
    channel.send("user").then(msg => msg.delete(10000));

    const channel2 = member.guild.channels.find('name', 'mod-logs');
    if (!channel2) return;
    
        if (moment().diff(moment(user.createdAt), 'days') < 5) {
            (`lol`)
            }

        let embed2 = new Discord.RichEmbed()
                .setAuthor("| New Member", "https://i.imgur.com/aKhj6Tr.png")
                 .setTitle(`Security Check Of ${user.tag}`)
                 .setDescription(`**User is __${member.guild.memberCount}th__ on this discord.**\n**Account Created: __${joinedAt}__ days ago**\n**Was Successfully Given __| Member__ Role.**\n**Invited By: __${inviter.tag}__**\n**Is User A Bot __${user.bot}__**`)
                 .setColor(`${colour}`)
                 .setThumbnail(user.displayAvatarURL)
                 .setFooter(`Security Check`)
        channel2.send({embed: embed2});
        });
  });

  bot.on("guildCreate", guild => {
    console.log(`The Bot Has Joined ${guild.name} , Owned By ${guild.owner.user.tag}`);

  });
      
bot.login(token);