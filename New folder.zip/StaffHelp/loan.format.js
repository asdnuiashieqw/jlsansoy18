const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'

        // Permission Verification -- This will only run if a user has a certain permission
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
        message.delete();
        
        let loan = new Discord.RichEmbed()
        .setColor("#9B5986")
        .setAuthor(message.guild.name)
        .setDescription(`
**Before you begin filling out the following information you must read the following [Loan Restrictions](http://centralhq.net/terms/loan-restrictions) if you're eligible for a loan!**

To request a loan please fill out this form.
        
1. How much would you like to loan from us?:
2. When are you planning to pay us back?: 
3. From where will you get your money to pay us back: 
4. Why do you need this loan: 
5. How much will you pay us back?
6. When do you need this loan?
7. Where did you find us (website/discord) provide link:
8. Please register on our website http://centralhq.net/register and provide your first and last name:

(OPTIONAL) Mc-Market Link/Another website similar to MC-M - This is to see your reputation.`)

        .setThumbnail("https://i.imgur.com/8oq50J6.png")
      
        message.channel.send(loan);
}

        exports.config = {
            name: 'loan.format'
            }