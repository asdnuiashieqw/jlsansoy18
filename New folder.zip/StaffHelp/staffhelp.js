const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'
    
            // Permission Verification -- This will only run if a user has a certain permission
            if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    

    const colour = ("#b80c0c");
    const embed = new Discord.RichEmbed()
    .setTitle(`**${message.guild.name} StaffHelp Panel**`)
    .setDescription("Hello! Here's a list of StaffHelp commands.")
    .addField("``StaffHelp Commands:``", 
`
**${prefix}announce <message>**
Announce a message with embed style.
**${prefix}loan.format**
Provides a loan format to the client.
**${prefix}close24 <user>**
Informs the user if they do not respond ticket will be closed in 24 hours.
**${prefix}close48 <user>**
Informs the user if they do not respond ticket will be closed in 48 hours.
**${prefix}freelancer.application**
Provides freelancer a application.`)
    .setColor(`${colour}`)
    .setFooter("StaffHelp Panel | Developed By David_#2469")
    .setThumbnail("https://i.imgur.com/8oq50J6.png")
    message.channel.send({embed: embed});

}
exports.config = {
name: 'staffhelp'
}