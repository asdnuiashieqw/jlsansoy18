const Discord = require('discord.js')
exports.run = (bot,message,args) => {
	
    if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
	if (!args[0]) return message.channel.send('**Proper Usage:** -close24 @David_#2469');
        let user = message.mentions.users.first() || message.author; 
        const embed = new Discord.RichEmbed()

        .setColor("#9B5986")
		.setAuthor(message.guild.name)
        .setDescription(`**Dear <@${user.id}>**,\n
		We would like to inform you that your ticket will be closed in __24 hours.__\n 
		**Reason** ➜ We will close this ticket if we do not receive a response from you.`)
        .setThumbnail(message.guild.iconURL)

        message.channel.send({embed: embed});

        message.delete().catch();
        }
    exports.config = {
    name: 'close24'
    }