const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'

        // Permission Verification -- This will only run if a user has a certain permission
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');

        let botmessage = args.join(" ");
        const embed = new Discord.RichEmbed()

        .setColor("#9B5986")
        .setAuthor(message.guild.name)
        .setDescription(`Thank you for applying for a developers position here at CentralHQ. We would like to ask you a few questions from the start.

1. Do you have a portfolio? If yes, please provide it.
2. If you have MC-Market.org account please provide it.
3. How old are you?
4. How long have you been coding (drawing/editing/etc...)?
5. Do you work for other companies?
6. How much time do you have to code (draw/edit/etc...)? Is it your full-time job or a free time activity?`)
        .setThumbnail(message.guild.iconURL)

        message.channel.send({embed: embed});

        message.delete().catch();

        }
    exports.config = {
    name: 'freelancer.application'
    }