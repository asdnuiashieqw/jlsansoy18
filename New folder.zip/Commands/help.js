const Discord = require('discord.js')
const version = ("CentralHQ Investments | Developed By David_#2469");
const colour = ("#0047ff");
exports.run = (bot,message,args) => {
    let prefix = '-'
    
    const embed = new Discord.RichEmbed()
    .setTitle("**CentralHQ Investments**")
    .setDescription("Hello! Here's a list of commands that can help you.")
    .addField("``User Commands:``", 
            `
**${prefix}invest <Number>**
Shows our up to date investment payouts.
**${prefix}ticket [reason]**
Open a support ticket.
**${prefix}invite.format**
Displays our invite format.
**${prefix}membercount**
Displays our discords statistics.
**${prefix}moderation**
Shows a list of moderator commands.
**${prefix}userinfo <Member>**
Shows detailed information about a user.`)
    .setColor(`${colour}`)
    .setFooter(`${version}`)
    .setThumbnail("https://i.imgur.com/8oq50J6.png")
message.channel.send({embed: embed});
        
        }
    exports.config = {
    name: 'help'
    }