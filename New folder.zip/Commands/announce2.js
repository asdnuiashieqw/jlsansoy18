const Discord = require('discord.js')
const client = new Discord.Client();
exports.run = (bot,message,args) => {
    let prefix = '-'

        // Permission Verification -- This will only run if a user has a certain permission
        if (!message.member.hasPermission('ADMINISTRATOR') || message.member.roles.has('📈 | Staff Manager')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
        
        // First, we want to check if the user had input
        if (!args[0]) return message.channel.send('**Proper Usage:** -announce <message>');

        let botmessage = args.join(" ");
        const embed = new Discord.RichEmbed()

        .setColor("#e4a2e5")
        .setAuthor(message.guild.name)
        .setDescription(botmessage)
        .setThumbnail(message.guild.iconURL)
        
        message.channel.send(botmessage)

        message.delete().catch();

        }
    exports.config = {
    name: 'announce2'
    }

