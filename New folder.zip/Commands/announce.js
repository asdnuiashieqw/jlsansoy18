const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'

        // Permission Verification -- This will only run if a user has a certain permission
        if (!message.member.hasPermission('ADMINISTRATOR') || message.member.roles.has('📈 | Staff Manager')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
        
        // First, we want to check if the user had input

        let botmessage = args.join(" ");
        const embed = new Discord.RichEmbed()

        .setColor("#    e4a2e5")
        .setDescription(botmessage)
        
        message.channel.send({embed: embed});

        message.delete().catch();

        }
    exports.config = {
    name: 'announce'
    }