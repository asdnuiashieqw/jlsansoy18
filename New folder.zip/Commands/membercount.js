const Discord = require('discord.js')
const moment = require('moment');
exports.run = (client, message, args, tools) => {
    let prefix = '-'

    var sentat = moment().calendar(); 

        let user = message.mentions.users.first() || message.author;
        const embed = new Discord.RichEmbed()
        
        .setAuthor(message.guild.name, message.guild.iconURL)
		.setColor('#0099ff')
        .addField(':family_mwgb: All Members', `${message.guild.memberCount}`, true)
        .addField(':runner: Humans', `${message.guild.members.filter(member => !member.user.bot).size}`, true)
        .addField('<:Online:468772646608175114> Currently Online', message.guild.members.filter(m => m.presence.status !== "offline").size, true)
        .addField('🤖 Bots', `${message.guild.members.filter(member => member.user.bot).size}`, true)
        .setTimestamp()
        message.channel.send(embed)

}
        
    exports.config = {
    name: 'membercount'
    }