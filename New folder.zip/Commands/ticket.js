const Discord = require('discord.js');

exports.run = (bot,message,args) => {
    let prefix = '-'
	
	if(message.channel.name !== 'bot-commands'){
		message.delete(10000);
		
	const embed2 = new Discord.RichEmbed()
        
    .setDescription('Please use bot commands in <#452685245104390164>')
	message.channel.send(embed2).then(msg => msg.delete(10000));
	
	}else{
    let botmessage = args.join(" ");

    const embed = new Discord.RichEmbed()
    .setColor("#8b18da")
    .setDescription("<a:CentralHQ_Loading:471769436089483266> Please wait, your ticket is being prepared.\n\nIf your ticket is not opened in less 5 minutes report it to staff and do not spam ``-ticket``")
    message.channel.send(embed).then(msg => msg.delete(15000));
	}
}
exports.config = {
name: 'ticket'
}