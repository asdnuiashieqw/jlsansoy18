const Discord = require("discord.js");
const axios = require("axios");


module.exports.run = async (bot, message, args) => {

  if (message.content.toLowerCase()) foundInText = true;

  if(message.member.hasPermission('MANAGE_MESSAGES')){

  if (!args[0]) return message.channel.send('**Proper Usage:** -crypto (Symbol)');

  let cryptos = args.join(" ");
  const arr = [];
     
      const cryptoUrl = `https://api.coinmarketcap.com/v1/ticker/${cryptos}`;
      arr.push(axios.get(cryptoUrl));

      const arr2 = [];

      const cryptoUrl2 = `https://api.coinmarketcap.com/v1/ticker/${cryptos}/?convert=ETH&limit=0`;
      arr2.push(axios.get(cryptoUrl2));

  
  Promise.all(arr && arr2).then((response) =>
  response.map(res => { 

        const embed = new Discord.RichEmbed()
        .setAuthor(`${res.data[0].name} | ${res.data[0].symbol} (1/5)`, `https://s2.coinmarketcap.com/static/img/coins/64x64/${res.data[0].id}.png`)
        .setColor('#4893fb')
        .setDescription(`
**Rank** ${res.data[0].rank}

**Price USD:** $${res.data[0].price_usd}
**Price BTC:** ${res.data[0].price_btc} BTC
**Price ETH:** ${res.data[0].price_eth} ETH

**Market Cap:** $${res.data[0].market_cap_usd}
**24h volume:** $${res.data[0]["24h_volume_usd"]}
**Supply:** ${res.data[0].total_supply}

**Change 1h:** ${res.data[0].percent_change_1h}%
**Change 24h:** ${res.data[0].percent_change_24h}%
**Change in 7d:** ${res.data[0].percent_change_7d}%`)

        .setThumbnail(`https://s2.coinmarketcap.com/static/img/coins/64x64/${res.data[0].rank}.png`)
        .setTimestamp()
        .setFooter(`CentralHQ.Net | Investments And More `, `${message.guild.iconURL}`);
        message.channel.send(embed);
      })
).catch((err) => message.channel.send('Seems that your posted crypto currency is wrong. Try again!'));



}else{

  const embed2 = new Discord.RichEmbed()
        
  .setDescription('Please use bot commands in #bot-commands')
  if (message.channel.name !== 'bot-commands') return message.delete(10000).then(message.channel.send(embed2).then(msg => msg.delete(10000)));

  if (!args[0]) return message.channel.send('**Proper Usage:** -crypto (Symbol)');

  let cryptos = args.join(" ");
  const arr = [];
     
      const cryptoUrl = `https://api.coinmarketcap.com/v1/ticker/${cryptos}`;
      arr.push(axios.get(cryptoUrl));

      const arr2 = [];

      const cryptoUrl2 = `https://api.coinmarketcap.com/v1/ticker/${cryptos}/?convert=ETH&limit=0`;
      arr2.push(axios.get(cryptoUrl2));

  
  Promise.all(arr && arr2).then((response) =>
  response.map(res => { 

        const embed = new Discord.RichEmbed()
        .setAuthor(`${res.data[0].name} | ${res.data[0].symbol} (1/5)`, `https://s2.coinmarketcap.com/static/img/coins/64x64/${res.data[0].id}.png`)
        .setColor('#4893fb')
        .setDescription(`
**Rank** ${res.data[0].rank}

**Price USD:** $${res.data[0].price_usd}
**Price BTC:** ${res.data[0].price_btc} BTC
**Price ETH:** ${res.data[0].price_eth} ETH

**Market Cap:** $${res.data[0].market_cap_usd}
**24h volume:** $${res.data[0]["24h_volume_usd"]}
**Supply:** ${res.data[0].total_supply}

**Change 1h:** ${res.data[0].percent_change_1h}%
**Change 24h:** ${res.data[0].percent_change_24h}%
**Change in 7d:** ${res.data[0].percent_change_7d}%`)

        .setThumbnail(`https://s2.coinmarketcap.com/static/img/coins/64x64/${res.data[0].rank}.png`)
        .setTimestamp()
        .setFooter(`CentralHQ.Net | Investments And More `, `${message.guild.iconURL}`);
        message.channel.send(embed);
      })
).catch((err) => message.channel.send('Seems that your posted crypto currency is wrong. Try again!'));
}
}
    exports.config = {
        name: 'crypto'
        }