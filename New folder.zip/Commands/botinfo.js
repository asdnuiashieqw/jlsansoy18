const Discord = require('discord.js')
const platform = require('platform')

exports.run = (bot,message,args) => {
            let user = message.mentions.users.first() || message.author;

            let totalSeconds = (bot.uptime / 1000);
            let days = Math.floor(totalSeconds / 86400);
            totalSeconds %= 86400;
            let hours = Math.floor(totalSeconds / 3600);
            totalSeconds %= 3600;
            let minutes = Math.floor(totalSeconds / 60);
            let seconds = Math.floor(totalSeconds % 60);

            let uptime = `${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`;

			const pinger = Math.ceil(bot.ping);
			
            const embed = new Discord.RichEmbed()
            .setAuthor("CentralHQ", "https://i.imgur.com/8oq50J6.png")
            .setColor("#9B5986")
            .addField("Version", "Beta 0.6.1", true)
            .addField("Server Name", message.guild.name, true)
            .addField("Developer", "David_#2469", true)
            .addField("Website", `[centralhq.net](http://centralhq.net)`, true)
            .addField("Users", bot.users.size, true)
            .addField("Ping", pinger, true)
            .addField("Node", `<:nodejs:473598679086006284> ${process.version}`, true)
            .addField("OS", (platform.os), true)
            .addField("Memory Usage", `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`, true)
            .setFooter(`Uptime:  ${uptime}`)
            message.channel.send({embed: embed});
        }

    exports.config = {
    name: 'botinfo'
    }

    function round(value, decimals) {
        return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals).toFixed(decimals);
    }