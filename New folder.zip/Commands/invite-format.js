const Discord = require('discord.js')
exports.run = (bot, message, args) => {
    let prefix = '-'

    message.channel.send("**CentralHQ Invite Format**\n```**CentralHQ Investments**\n\n• CentralHQ is the place for you to invest and receive some extra money with no hesitation!\n• Our community is amazing and always up for a help. If you have any questions how our company works just join our discord and ask any question and we will answer it ;)\n\n- :money_with_wings:  Investments!\n- :wave: Great community.\n- :tada: Giveaways\n- :incoming_envelope: 24/7 support from our staff members\n- :thumbsup: Easy, simple and efficient.\n\nLinks:\n**Website**: http://centralhq.net\n**Learn More**: http://centralhq.net/discord\n**Discord**: YOUR LINK```");
}

exports.config = {
    name: 'invite.format'
}