const Discord = require('discord.js');

exports.run = (bot,message,args) => {
    let prefix = '-'
	
	if(message.channel.name !== 'bot-commands'){
		message.delete(10000);
		
	const embed2 = new Discord.RichEmbed()
        
    .setDescription('Please use bot commands in <#452685245104390164>')
	message.channel.send(embed2).then(msg => msg.delete(10000));
	
	}else{
    let botmessage = args.join(" ");
	message.delete(10000);

    const embed = new Discord.RichEmbed()
    .setColor("#8b18da")
    .setDescription("<:CentralHQ_Disapproved:466943866000637952> Mhm, seems that you're using a wrong command to create a ticket. Maybe try ``-ticket``.")
    message.channel.send(embed).then(m => m.delete(10000))
	}
}
exports.config = {
name: 'new'
} 
