const Discord = require('discord.js')
exports.run = (bot, message, args) => {
    let prefix = '-'

	if(message.member.hasPermission('MANAGE_MESSAGES')){
		
    if (!args[0]) return message.channel.send('No amount has been given!');
    let arg = args.slice(0).join(" ");
    let botmessage = args.join(" ");

    if(isNaN(arg)) return message.channel.send('Please use numbers not letters!');

    const argNum = Number(arg);

    if(argNum < 15) return message.channel.send('We cannot accept investments lower than $15!');    
    if(argNum > 300) return message.channel.send('Seems that you have reached investment limit. Due to security reasons and safety of your investment we cannot accept investments bigger than 300€.');    
    const earn = Number(argNum * 0.1);
    const client = round(Number(argNum + (earn * 10)), 2);
    
    
    const embed = new Discord.RichEmbed()
    .setDescription(`__**Investments profit calculator**__ 
    
Ah, I can see that you're interested in investing. 
That's great! Lets see what you can get back 
with your provided information.If you invest __${arg}$__
you can expect to receive back this.

 **Investment Return**: $${client} USD
 **Estimated Time Arrival** 5-8 business days

**Website** https://quilfon.tech`)
    .setColor(`#0000FF`)
    message.channel.send({embed: embed});

	}else{
	const embed2 = new Discord.RichEmbed()
        
    .setDescription('Please use bot commands in #bot-commands')
    if (message.channel.name !== 'bot-commands') return message.delete(10000).then(message.channel.send(embed2).then(msg => msg.delete(10000)));

	if (!args[0]) return message.channel.send('No amount has been given!');
    let arg = args.slice(0).join(" ");
    let botmessage = args.join(" ");

    if(isNaN(arg)) return message.channel.send('Please use numbers not letters!');

    const argNum = Number(arg);

    if(argNum < 15) return message.channel.send('We cannot accept investments lower than $15!');    
    if(argNum > 300) return message.channel.send('Seems that you have reached investment limit. Due to security reasons and safety of your investment we cannot accept investments bigger than 300€.');  

    const earn = Number(argNum * 0.1);

    const client = round(Number(argNum + earn), 2);
    const premium = round(Number(argNum + (earn * 1.2)), 2);
    const og = round(Number(argNum + (earn * 1.45)), 2);
    const premium_og = round(Number(argNum + (earn * 1.65)), 2);

    const embedd = new Discord.RichEmbed()
    .setDescription(`**Investments profit calculator** <:634785041762877441>
    
Ah, I can see that you're interested in investing. That's great! Lets see what you can get back with your provided information.
If you invest __${arg}€__ you can expect to receive back this.

Client: *${client}€*
Premium Client: *${premium}€*
Enterprise Client: *${og}€*
Premium + Enterprise Clients: *${premium_og}€*


**Do you want to receive a higher profit?**
Upgrade your account today at [Account Upgrades](http://quilfon.tech/prices)

To start investing visit **[Investment Plans](http://quilfon.tech/invest)**`)
    .setColor(`#b30086`)
    message.channel.send(embedd);

	}
}

exports.config = {
    name: 'invest'
}

function round(value, decimals) {
    return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals).toFixed(decimals);
}