const Discord = require('discord.js');

exports.run = async (bot, message, args, tools) => {

    if(message.channel.name !== 'bot-commands'){
	message.delete(10000);
		
	const embed2 = new Discord.RichEmbed()
        
    .setDescription('Please use bot commands in <#452685245104390164>')
	message.channel.send(embed2).then(msg => msg.delete(10000));
	
	}else{
    // First, we want to check if the user had input
	message.delete(10000);
    if (!args[0]) return message.channel.send('**Proper Usage:** -suggestion (your suggestion towards CentralHQ developent)').then(msg => msg.delete(10000));

    //Then, create the embed
	
	const suggestionsend = message.guild.channels.find('name', 'suggestions');
	
    const embed = new Discord.RichEmbed()
        .setColor(777777)
		.setAuthor(`Suggestion by ${message.author.username}`, message.author.avatarURL)
        .setFooter('Create a suggestion with "-suggestion"!')
        .setDescription(args.join(' '));

    //Finally, using await send the message
    let msg = await suggestionsend.send(embed);
    //The sent message will now be stored in the msg variable

    //React to the message
    await msg.react(`466940628656455682`); // Using await here will make sure the first one runs before the second one
    await msg.react(`466943866000637952`);

    // Make sure you delete the original message
    message.delete({timeout: 1000}); //This waits 1000 miliseconds before deleting (1 second.)
	
	message.channel.send('<:CentralHQ_Approved:466939765649047553> Your suggestion has been posted!').then(msg => msg.delete(10000));
	
	}
}
exports.config = {
name: 'suggestion'
} //Needs to be added so the bot can store the command name