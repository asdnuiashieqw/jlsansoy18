const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'
    
            // Permission Verification -- This will only run if a user has a certain permission
            if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    

    const colour = ("#b80c0c");
    const embed = new Discord.RichEmbed()
    .setTitle(`**${message.guild.name} Admin Panel**`)
    .setDescription("Hello! Here's a list of admin commands.")
    .addField("``Admin Commands:``", 
`
**${prefix}announce <message>**
Announces something in a channel that you write the command.
**${prefix}poll**
Creates a poll on which users can vote.
**${prefix}locked.info**
Displays all locked users.
**${prefix}moderation**
See a list of moderation commands.
**${prefix}botinfo**
Displays up to date bot statistics.`)
    .setColor(`${colour}`)
    .setFooter("Admin Panel | Developed By David_#2469")
    .setThumbnail("https://i.imgur.com/8oq50J6.png")
    message.channel.send({embed: embed});

}
exports.config = {
name: 'admin'
}