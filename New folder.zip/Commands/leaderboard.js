const Discord = require("discord.js"),
arraySort = require('array-sort');

exports.run = async (bot,message,args) => {
    let invites = await message.guild.fetchInvites().catch(error => {
        return message.channel.send('Sorry, I don\'t have the proper permissions to view invites!');
    });

    invites = invites.array();

    arraySort(invites, 'uses', { reverse: true});

    const objData = {};
    invites.forEach(function(invites) {
        if(!invites.inviter) return;
        if (!objData[invites.inviter.username]) { // look if the user is already in the objData, if it's not in it the if will get executed
        objData[invites.inviter.username] = invites.uses; 
        } else objData[invites.inviter.username] += invites.uses; // if the user is already in it, it will add the uses to it
    });
    
let temp = [];
Object.keys(objData).forEach(user => temp.push({uses: objData[user], "name": user}));
arraySort(temp, 'uses', { reverse: true});
let possibleinvites = [];
temp .forEach((user, ind) => {
    if (ind >= 10) return;
    possibleinvites.push(`<:CentralHQ_Invites_Arrow:477389395591299076>  **${user.name}** *${user.uses} invites*`);
});
    
    const embed = new Discord.RichEmbed()
            .setColor(0xCB5A5E)
            .addField('**Invites Leaderboard**', `${possibleinvites.join(`\n`)}`)
        message.channel.send(embed)
}

exports.config = {
    name: 'leaderboard'
    }