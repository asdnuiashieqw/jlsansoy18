const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    let prefix = '-'
    
            // Permission Verification -- This will only run if a user has a certain permission
            if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');    

    const colour = ("#b80c0c");
    const embed = new Discord.RichEmbed()
    .setTitle(`**${message.guild.name} Moderation Panel**`)
    .setDescription("Hello! Here's a list of moderation commands.")
    .addField("``Moderation Commands:``", 
`
**${prefix}clear <user/blank> <amount>**
Clears messages from the channel.
**${prefix}lock <user> <reason>**
Lock user for breaking rules.
**${prefix}unlock <user>**
Unlock a locked user.
**${prefix}lockdown <time/unlock>**
Locks down or unlocks the channel so people couldn't write in it.
**${prefix}warn <user> <reason>**
Warns user.
**${prefix}warnlevel <user>**
Shows how many warnings this user has.
**${prefix}mute <user> <time/blank> <reason>**
Mutes the user.
**${prefix}kick <user> <reason>**
Kick a user.
**${prefix}ban <user> <reason>**
Shows how many warnings this user has.`)
    .setColor(`${colour}`)
    .setFooter("Moderation Panel | Developed By David_#2469")
    .setThumbnail("https://i.imgur.com/8oq50J6.png")
    message.channel.send({embed: embed});

}
exports.config = {
name: 'moderation'
}