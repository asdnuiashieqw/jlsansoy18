const Discord = require('discord.js');

exports.run = async (bot, message, args, tools) => {

    //This will contain some extra things

    // Permission Verification -- This will only run if a user has a certain permission
    if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('<:CentralHQ_Disapproved:466943866000637952> You do not have permissions to do this.');
    
    // First, we want to check if the user had input
    if (!args[0]) return message.channel.send('**Proper Usage:** -poll question');

    //Then, create the embed
    const embed = new Discord.RichEmbed()
        .setColor(777777)
        .setFooter('React to vote!')
        .setDescription(args.join(' '))
        .setTitle(`Poll Created By ${message.author.username}`);

    //Finally, using await send the message
    let msg = await message.channel.send(embed);
    //The sent message will now be stored in the msg variable

    //React to the message
    await msg.react(`466940628656455682`); // Using await here will make sure the first one runs before the second one
    await msg.react(`466943866000637952`);

    // Make sure you delete the original message
    message.delete({timeout: 1000}); //This waits 1000 miliseconds before deleting (1 second.)
}
exports.config = {
name: 'poll'
} //Needs to be added so the bot can store the command name