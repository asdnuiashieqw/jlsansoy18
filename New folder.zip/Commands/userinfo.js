const Discord = require('discord.js')
exports.run = (bot,message,args) => {
    
            let user = message.mentions.users.first() || message.author; 
            const embed = new Discord.RichEmbed()
            .setThumbnail(user.avatarURL)
            .setAuthor(`Dear, ${message.author.username}`)
            .setDescription("This is your requested user's info!")
            .setColor("#9B5986")
            .addField("Full Username", user.tag)
            .addField("ID", user.id)
            .addField("Bot Account?", user.bot)
            .addField("Invited By", user.inviter)
            .addField("Created At", user.createdAt)
            .addField(`Joined ${message.guild.name } At`, message.guild.member(user).joinedAt);
            message.channel.send({embed: embed});
        }
    exports.config = {
    name: 'userinfo'
    }