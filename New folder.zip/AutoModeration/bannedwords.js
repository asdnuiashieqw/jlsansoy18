const Discord = require("discord.js");
const moment = require('moment');
module.exports = {
    on: 'message',
    code(message) {
    let blacklisted = [
        'fuck',
        'nigg',
        'fuk',
        'cunt',
        'cnut',
        'bitch',
        'dick',
        'd1ck',
        'pussy' ,
        'asshole',
        'b1tch',
        'b!tch',
        'blowjob',
        'cock',
        'c0ck',
        'hoe',
        'h0e',
        'motherfucket',
        'fucker',
        'pernis',
        'pen1s',
        'whore',
        'shit',
        'sh!t',
        'nigga',
        'cunt'
    ];

    let foundInText = false;
    for (var i in blacklisted) {
        if (message.content.toLowerCase().includes(blacklisted[i].toLowerCase())) foundInText = true;
    }

    if (foundInText) {
        message.delete();
        message.channel.send('<:CentralHQ_Disapproved:466943866000637952> Sorry, that word is blacklisted').then(msg => msg.delete(5000));

        const swearwords = message.guild.channels.find("name", "mod-logs");
        if(!swearwords) return message.reply("Couldn't find channel #mod-logs, please create it.");
    
        let user = message.mentions.users.first() || message.author;

        var sentat = moment().calendar();  

        const embed = new Discord.RichEmbed()
            .setDescription(`${user} Used a banned word/link!`)
            .setColor("#f00202")
            .addField('Affected Channel', message.channel)
            .addField('Message Removed', message.content)
            .addField('Reason', 'Blackisted Words')
            .setThumbnail(user.displayAvatarURL)
			.setTimestamp()
            .setFooter(`ID: ${user.id}`)
    
            swearwords.send(embed);
    
    }}
};
